# Vundle Puppet Module for Boxen

[![Build Status](https://travis-ci.org/bdossantos/puppet-vundle.png?branch=master)](https://travis-ci.org/bdossantos/puppet-vundle)

## Usage

```puppet
include vundle
```

## Required Puppet Modules

None.
